#include <stdio.h>

int main(){
	printf("Hello, Yaron!!!\n");
	return 0;

}

